# A.Pcalculator_FxteV1.PY

Just a simple Python based calculator for Arithmetic Progression (AP) problems.

## Features =
- Calculate nth term of an AP.
- Calculate the sum of the first n terms.

## Installation =
Clone the repository:
```bash
git clone https://github.com/fxteduelist/A.Pcalculator_FxteV1.PY.git
cd A.Pcalculator_FxteV1.PY
